## 3.0.1 # 2020-09-02
- Update libs
- Fixed minor bugs

## 3.0.0 # 2020-07-16
- Upgrade support to PHP 7.2 from 7.1
- Upgraded to Laravel 6(LTS) from 5.8
- Bug fixes
- Update libraries
- Add new features
    - Super admin access
    - Promotion module
- Improve security, performance & UI
- Remove features
    - Attendance upload
    - Academic Calendar
    - Work outside

## 2.0.4 # 2019-08-13
- Bug fixes
- Update libraries

## 2.0.3 # 2019-07-22
- Bug fixes
- Update frontend libs
- add laravel queue support for sms and email sending

## 2.0.2 # 2019-06-22
- Upgraded to Laravel 5.8 from 5.6
- Update dependency libraries

## 2.0.1 # 2019-06-02
- Bug fixes

## 2.0.0 # 2019-05-31
- 2nd stable release
- Build with PHP 7.1 & Laravel 5.6
- Complete re-write from v1.0
- Added lot's of new features
- New theme
- Fronted website added

## 1.0.0 # 2018-05-18
- First stable release
- Build with PHP 5.6 & Laravel 4.2

## 0.1.0 # 2016-02-14
- Init here
- Build with PHP 5.6 & Laravel 4.2